//Jorge Quinones Rios, April 18 2013, Expressions

//How many times I eat in a week//
var mealsAday = prompt("How many times do I eat in a week?");
if (mealsAday > 21)
{
    console.log("Wrong!");
    alert("Wrong!");
    var mealsAday = prompt("How many times do I eat in a week?");
}

if (mealsAday < 21)
{
    console.log("Wrong!");
    alert("Wrong!");
    var mealsAday = prompt("How many times do I eat in a week?");
    
}

if (mealsAday == 21)
{
    console.log("Correct!, you may proceed");
    alert("Correct!, you may proceed");
    
}

if (alert =="Correct!, you may proceed")
   console.log("Correct!, you may proceed")
    
{
        alert("Welcome!");
        console.log("Welcome");
}

if (alert =="Welcome!");
   console.log("Welcome!");
   
{
index.html;
}
       
if (mealsAday == "I don't know")
{
    console.log("Please enter a number");
    alert("Please enter a number");
}

if (alert == "Please enter a number")
   (console.log == "Please enter a number")
{
    alert("Try again")
    console.log("Try again");
}    
if (alert == "Try again")
   (console.log == "Try again")
{
    
    var mealsAday = prompt("How many times do I eat in a week")
    console.log("How many times do I eat in a week");//
}

if (alert == "var mealsAday = prompt")
   console.log("var mealsAday")
   
{
    alert("Try again")
    console.log("Try again");
    
   }


//meals I eat a day//
var mealsAday = 3;

//how many days in a week//
var daysInaweek = 7;

//how many meals I eat a week//
var mealsInaweek = mealsAday * daysInaweek;
console.log("Meals in a week:" + mealsInaweek);
alert("Meals in a week:" + mealsInaweek);
